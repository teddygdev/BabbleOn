# import the Flask class from the flask module
from flask import Flask, render_template, redirect, \
    url_for, request, session, flash, g
from functools import wraps
import mysql.connector

# create the application object
app = Flask(__name__)

# config
app.secret_key = 'f7d8fd7sgd0fuf0uhrv0vrv8jr0j09jv0jv0j0rejv0j'

# login required decorator
def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('You need to login first.')
            return redirect(url_for('welcome'))
    return wrap

# use decorators to link the function to a url
@app.route('/changepass', methods=['GET', 'POST'])
@login_required
def changepass():
    error = None
    if request.method == 'POST':
        if request.form['pass'] != request.form['pass2'] :
            error = 'Passwords Don\'t Match. Please try again.'
        elif request.form['pass'] == '' or request.form['pass2'] == '' :
            error = 'One or more fields are blank. Please enter a new password.'
        else:
            g.db = connect_db()
            cur = g.db.cursor()
            query = """UPDATE login SET password=%s WHERE email=%s"""
            cur.execute(query, (request.form['pass'], session['y34n491'],))
            g.db.commit()
            cur.close()
            g.db.close()
            flash('Your password is changed.')
            return redirect(url_for('home'))
    return render_template('changepass.html', error=error)

# use decorators to link the function to a url
@app.route('/create', methods=['GET', 'POST'])
def create():
    error = None
    if request.method == 'POST':
        if request.form['pass'] != request.form['pass2'] :
            error = 'Passwords Don\'t Match. Please try again.'
        elif request.form['email'] == '' or request.form['pass'] == '' or \
             request.form['fname'] == '' or request.form['lname'] == '' or \
             request.form['tel'] == '':
            error = 'Empty or invalid fields. Please try again.'
        else:
            g.db = connect_db()
            cur = g.db.cursor()
            query = """INSERT INTO `chatserver`.`login` (`user_id`, `email`, `password`, \
                     `create_time`, `first_name`, `last_name`, `phone`, `profile_pic`) \
                     VALUES (NULL,%s, %s, CURRENT_TIMESTAMP, %s, %s, %s, NULL)"""
            cur.execute(query, (request.form['email'], request.form['pass'], \
                      request.form['fname'], request.form['lname'], request.form['tel']))
            g.db.commit()
            cur.close()
            g.db.close()
            flash('Account Made.')
            return redirect(url_for('home'))
    return render_template('create.html', error=error)

# use decorators to link the function to a url
@app.route('/')
@login_required
def home():
    # return "Hello, World!"  # return a string
    #g.db = connect_db()
    #cur = g.db.cursor()
    #posts = cur.execute('select * from login')
    #cur.fetchall()
    #cur.close()
    #g.db.close()
    return render_template('index.html')  # render a template


@app.route('/welcome')
def welcome():
    return render_template('welcome.html')  # render a template


# route for handling the login page logic
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
	g.db = connect_db()
        cur = g.db.cursor()
        query = """SELECT email FROM login \
                 WHERE email = %s AND password = %s"""
        cur.execute(query, (request.form['username'], request.form['password']))
        cur.fetchall()
        valid = cur.rowcount

        cur.close()        
        g.db.close()
        if valid == 0 :
            error = 'Invalid Credentials. Please try again.'
        else:
            session['logged_in'] = True
            session['y34n491'] = request.form['username'] 
            flash('You were logged in.')
            return redirect(url_for('home'))
    return render_template('login.html', error=error)


@app.route('/logout')
@login_required
def logout():
    session.pop('logged_in', None)
    flash('You were logged out.')
    return redirect(url_for('welcome'))

config = {
  'user': 'root',
  'password': 'donahoo',
  'host': '127.0.0.1',
  'database': 'chatserver',
  'raise_on_warnings': True,
  'use_pure': False,
}

# connect to database
def connect_db():
    return mysql.connector.connect(**config)


# start the server with the 'run()' method
if __name__ == '__main__':
    app.debug = True
    app.run('192.168.1.110')
